package com.r3.findmestuff;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class LostItems extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lost_items);
    }
}