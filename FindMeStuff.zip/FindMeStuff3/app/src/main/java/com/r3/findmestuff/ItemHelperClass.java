package com.r3.findmestuff;

public class ItemHelperClass {
    String Iname, Idescription, Iimage;


    public ItemHelperClass(String Iname, String Idescription) {

    }

    public ItemHelperClass(String Iname, String Idescription, String Iimage) {
        this.Iname = Iname;
        this.Idescription = Idescription;
        this.Iimage = Iimage;

    }

    public String getIname() {
        return Iname;
    }

    public void setIname(String Iname) {
        this.Iname = Iname;
    }

    public String getIdescription() {
        return Idescription;
    }

    public void setIdescription(String Idescription) {
        this.Idescription = Idescription;
    }

    public String getIimage() {
        return getIimage();
    }

    public void setIimage(String Iimage) {

        this.Iimage = Iimage;
    }


}